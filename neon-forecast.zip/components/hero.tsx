import { ShieldCheck, Zap } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { TradingTerminal } from '@/components/trading-terminal'

export function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="grid-bg pointer-events-none absolute inset-0 [mask-image:radial-gradient(ellipse_at_top,black,transparent_75%)]" />
      <div className="pointer-events-none absolute -top-40 left-1/2 h-80 w-[42rem] -translate-x-1/2 rounded-full bg-primary/15 blur-[120px]" />

      <div className="relative mx-auto max-w-6xl px-4 pb-16 pt-16 sm:px-6 sm:pt-24">
        <div className="mx-auto max-w-3xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-xs font-medium text-primary backdrop-blur-sm">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-pulse-dot rounded-full bg-primary" />
            </span>
            AI-Powered Quant Forecast v4.2 Active
          </div>

          <h1 className="mt-6 text-balance text-4xl font-bold leading-tight tracking-tight sm:text-5xl md:text-6xl">
            Maximize ROI with{' '}
            <span className="text-neon-gradient">High-Precision Algorithmic Forecasts</span>
          </h1>

          <p className="mx-auto mt-6 max-w-xl text-pretty text-base leading-relaxed text-muted-foreground sm:text-lg">
            NEON FORECAST fuses real-time market data with deep quant models to deliver
            actionable buy and sell signals across Bitcoin, stocks, and forex — the moment
            momentum shifts.
          </p>

          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Button
              size="lg"
              className="glow-neon w-full bg-primary font-semibold text-primary-foreground hover:bg-primary/90 sm:w-auto"
            >
              <Zap className="mr-1 h-4 w-4" aria-hidden="true" />
              Unlock Signals Now
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="w-full border-border bg-transparent text-foreground hover:bg-secondary sm:w-auto"
            >
              <ShieldCheck className="mr-1 h-4 w-4 text-primary" aria-hidden="true" />
              30-Day Guarantee
            </Button>
          </div>
        </div>

        <div className="mt-14">
          <TradingTerminal />
        </div>
      </div>
    </section>
  )
}
