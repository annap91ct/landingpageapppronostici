import { Activity } from 'lucide-react'
import { Button } from '@/components/ui/button'

const links = [
  { label: 'Features', href: '#features' },
  { label: 'Signals', href: '#signals' },
  { label: 'Pricing', href: '#pricing' },
]

export function Navbar() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/60 bg-background/70 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
        <a href="#" className="flex items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-md bg-primary/15 ring-1 ring-primary/40">
            <Activity className="h-4 w-4 text-primary" aria-hidden="true" />
          </span>
          <span className="font-mono text-sm font-bold tracking-widest text-foreground">
            NEON<span className="text-primary">FORECAST</span>
          </span>
        </a>

        <nav className="hidden items-center gap-8 md:flex" aria-label="Primary">
          {links.map((l) => (
            <a
              key={l.label}
              href={l.href}
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <Button className="glow-neon bg-primary font-semibold text-primary-foreground hover:bg-primary/90">
          Get Started
        </Button>
      </div>
    </header>
  )
}
