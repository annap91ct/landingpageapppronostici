import { ArrowDownRight, ArrowUpRight } from 'lucide-react'

type Signal = {
  asset: string
  type: 'BUY' | 'SELL'
  entry: string
  target: string
  time: string
}

const signals: Signal[] = [
  { asset: 'BTC/USD', type: 'BUY', entry: '$64,120', target: '$73,200', time: '12s ago' },
  { asset: 'NVDA', type: 'BUY', entry: '$118.40', target: '$134.90', time: '1m ago' },
  { asset: 'ETH/USD', type: 'SELL', entry: '$3,410', target: '$3,090', time: '4m ago' },
  { asset: 'EUR/USD', type: 'BUY', entry: '1.0842', target: '1.0978', time: '7m ago' },
  { asset: 'SOL/USD', type: 'BUY', entry: '$146.20', target: '$172.50', time: '11m ago' },
  { asset: 'TSLA', type: 'SELL', entry: '$242.10', target: '$219.40', time: '15m ago' },
]

export function SignalsStream() {
  return (
    <section id="signals" className="scroll-mt-20 border-y border-border bg-secondary/20">
      <div className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
        <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-end">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-primary">Live Feed</p>
            <h2 className="mt-3 text-balance text-3xl font-bold tracking-tight sm:text-4xl">
              Recently triggered signals
            </h2>
          </div>
          <div className="flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1.5">
            <span className="h-1.5 w-1.5 animate-pulse-dot rounded-full bg-primary" />
            <span className="font-mono text-[11px] font-semibold tracking-widest text-primary">
              STREAMING
            </span>
          </div>
        </div>

        <div className="mt-10 grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {signals.map((s, i) => {
            const isBuy = s.type === 'BUY'
            return (
              <div
                key={`${s.asset}-${i}`}
                className="rounded-xl border border-border bg-card/70 p-5 backdrop-blur-sm"
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono text-sm font-bold text-foreground">{s.asset}</span>
                  <span
                    className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 font-mono text-xs font-bold ${
                      isBuy
                        ? 'bg-primary/15 text-primary'
                        : 'bg-destructive/15 text-destructive'
                    }`}
                  >
                    {isBuy ? (
                      <ArrowUpRight className="h-3 w-3" aria-hidden="true" />
                    ) : (
                      <ArrowDownRight className="h-3 w-3" aria-hidden="true" />
                    )}
                    {s.type}
                  </span>
                </div>

                <div className="mt-4 grid grid-cols-2 gap-3 font-mono">
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">
                      Entry
                    </p>
                    <p className="mt-0.5 text-sm text-foreground">{s.entry}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">
                      Target
                    </p>
                    <p className="mt-0.5 text-sm text-primary">{s.target}</p>
                  </div>
                </div>

                <p className="mt-4 font-mono text-[11px] text-muted-foreground">{s.time}</p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
