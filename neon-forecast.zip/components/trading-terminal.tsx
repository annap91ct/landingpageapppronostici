import { ArrowUpRight, TrendingUp } from 'lucide-react'
import { ForecastChart } from '@/components/forecast-chart'

const metrics = [
  { label: 'Estimated Win Rate', value: '87.4%', accent: 'text-primary' },
  { label: 'BTC/USD Signal', value: 'STRONG BUY', accent: 'text-primary' },
  { label: '24h Profit Target', value: '+14.2%', accent: 'text-primary' },
]

export function TradingTerminal() {
  return (
    <div className="mx-auto max-w-4xl overflow-hidden rounded-xl border border-border bg-card/70 shadow-2xl backdrop-blur-xl">
      {/* window header */}
      <div className="flex items-center justify-between border-b border-border bg-secondary/40 px-4 py-3">
        <div className="flex items-center gap-2">
          <span className="h-3 w-3 rounded-full bg-destructive/80" />
          <span className="h-3 w-3 rounded-full bg-chart-4/80" />
          <span className="h-3 w-3 rounded-full bg-primary/80" />
          <span className="ml-3 font-mono text-xs text-muted-foreground">
            neon_forecast — terminal
          </span>
        </div>
        <div className="flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-2.5 py-1">
          <span className="h-1.5 w-1.5 animate-pulse-dot rounded-full bg-primary" />
          <span className="font-mono text-[10px] font-semibold tracking-widest text-primary">
            LIVE DATA
          </span>
        </div>
      </div>

      {/* metrics */}
      <div className="grid grid-cols-1 gap-px bg-border sm:grid-cols-3">
        {metrics.map((m) => (
          <div key={m.label} className="bg-card px-5 py-4">
            <p className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
              {m.label}
            </p>
            <p className={`mt-1 font-mono text-xl font-bold ${m.accent}`}>{m.value}</p>
          </div>
        ))}
      </div>

      {/* chart */}
      <div className="relative border-t border-border bg-gradient-to-b from-card to-background/40 px-4 pb-4 pt-3">
        <div className="mb-2 flex items-center justify-between">
          <span className="flex items-center gap-1.5 font-mono text-xs text-muted-foreground">
            <TrendingUp className="h-3.5 w-3.5 text-primary" aria-hidden="true" />
            BTC/USD · 4H Forecast Model
          </span>
          <span className="flex items-center gap-1 font-mono text-xs font-semibold text-primary">
            <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
            projected +14.2%
          </span>
        </div>
        <div className="h-56 w-full">
          <ForecastChart />
        </div>
      </div>
    </div>
  )
}
