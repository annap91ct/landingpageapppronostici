'use client'

import { useEffect, useMemo, useState } from 'react'

const WIDTH = 640
const HEIGHT = 240
const POINTS = 48

function seededTrajectory(seed: number) {
  const values: number[] = []
  let v = 50
  for (let i = 0; i < POINTS; i++) {
    // pseudo-random walk with upward drift
    const noise = Math.sin(seed + i * 0.6) * 6 + Math.cos(seed * 0.5 + i * 0.27) * 4
    v += noise * 0.4 + 0.9
    values.push(v)
  }
  const min = Math.min(...values)
  const max = Math.max(...values)
  return values.map((val) => (val - min) / (max - min || 1))
}

function buildPath(norm: number[]) {
  const stepX = WIDTH / (norm.length - 1)
  const pad = 20
  const usable = HEIGHT - pad * 2
  return norm
    .map((n, i) => {
      const x = i * stepX
      const y = HEIGHT - pad - n * usable
      return `${i === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`
    })
    .join(' ')
}

export function ForecastChart() {
  const [seed, setSeed] = useState(1)

  useEffect(() => {
    const id = setInterval(() => setSeed((s) => s + 1), 3200)
    return () => clearInterval(id)
  }, [])

  const norm = useMemo(() => seededTrajectory(seed), [seed])
  const linePath = useMemo(() => buildPath(norm), [norm])
  const areaPath = useMemo(
    () => `${linePath} L ${WIDTH} ${HEIGHT} L 0 ${HEIGHT} Z`,
    [linePath],
  )

  const last = norm[norm.length - 1]
  const lastX = WIDTH
  const lastY = HEIGHT - 20 - last * (HEIGHT - 40)

  return (
    <svg
      viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
      className="h-full w-full"
      preserveAspectRatio="none"
      role="img"
      aria-label="Simulated BTC/USD forecast trajectory trending upward"
    >
      <defs>
        <linearGradient id="lineGrad" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#2962ff" />
          <stop offset="60%" stopColor="#00c2ff" />
          <stop offset="100%" stopColor="#00e676" />
        </linearGradient>
        <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#00e676" stopOpacity="0.28" />
          <stop offset="100%" stopColor="#00e676" stopOpacity="0" />
        </linearGradient>
        <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="4" result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* horizontal guide lines */}
      {[0.25, 0.5, 0.75].map((g) => (
        <line
          key={g}
          x1="0"
          x2={WIDTH}
          y1={HEIGHT * g}
          y2={HEIGHT * g}
          stroke="rgba(255,255,255,0.06)"
          strokeWidth="1"
        />
      ))}

      <path key={`area-${seed}`} d={areaPath} fill="url(#areaGrad)" className="transition-all duration-1000 ease-out" />
      <path
        key={`line-${seed}`}
        d={linePath}
        fill="none"
        stroke="url(#lineGrad)"
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        filter="url(#glow)"
        className="transition-all duration-1000 ease-out"
      />
      <circle cx={lastX} cy={lastY} r="5" fill="#00e676" filter="url(#glow)" className="transition-all duration-1000 ease-out">
        <animate attributeName="r" values="5;8;5" dur="1.4s" repeatCount="indefinite" />
      </circle>
    </svg>
  )
}
