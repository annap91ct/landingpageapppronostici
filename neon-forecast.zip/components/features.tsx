import { Bell, ShieldHalf, Layers } from 'lucide-react'

const features = [
  {
    icon: Bell,
    title: 'Real-time AI Alerts',
    desc: 'Instant push notifications the moment our models detect a high-confidence entry or exit — no lag, no noise.',
  },
  {
    icon: ShieldHalf,
    title: 'Risk Management Engine',
    desc: 'Every signal ships with dynamic stop-loss and position-sizing guidance calibrated to live volatility.',
  },
  {
    icon: Layers,
    title: 'Multi-Asset Coverage',
    desc: 'One dashboard for it all — Crypto, Stocks, and Forex forecasts running in parallel, 24/7.',
  },
]

export function Features() {
  return (
    <section id="features" className="mx-auto max-w-6xl scroll-mt-20 px-4 py-20 sm:px-6">
      <div className="mx-auto max-w-2xl text-center">
        <p className="font-mono text-xs uppercase tracking-widest text-primary">Capabilities</p>
        <h2 className="mt-3 text-balance text-3xl font-bold tracking-tight sm:text-4xl">
          Built for traders who move at machine speed
        </h2>
      </div>

      <div className="mt-12 grid grid-cols-1 gap-5 md:grid-cols-3">
        {features.map((f) => (
          <div
            key={f.title}
            className="group rounded-xl border border-border bg-card/60 p-6 backdrop-blur-sm transition-colors hover:border-primary/40"
          >
            <span className="inline-flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 ring-1 ring-primary/30 transition-shadow group-hover:glow-neon">
              <f.icon className="h-5 w-5 text-primary" aria-hidden="true" />
            </span>
            <h3 className="mt-5 text-lg font-semibold text-foreground">{f.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.desc}</p>
          </div>
        ))}
      </div>
    </section>
  )
}
