import { Navbar } from '@/components/navbar'
import { Hero } from '@/components/hero'
import { Features } from '@/components/features'
import { SignalsStream } from '@/components/signals-stream'
import { Button } from '@/components/ui/button'
import { Activity } from 'lucide-react'

export default function Page() {
  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      <Hero />
      <Features />
      <SignalsStream />

      {/* Pricing / CTA */}
      <section id="pricing" className="relative scroll-mt-20 overflow-hidden">
        <div className="pointer-events-none absolute left-1/2 top-1/2 h-72 w-[40rem] -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary/10 blur-[120px]" />
        <div className="relative mx-auto max-w-3xl px-4 py-24 text-center sm:px-6">
          <h2 className="text-balance text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            Start trading with a{' '}
            <span className="text-neon-gradient">statistical edge</span>
          </h2>
          <p className="mx-auto mt-5 max-w-xl text-pretty leading-relaxed text-muted-foreground">
            Join thousands of traders receiving high-precision forecasts. Cancel anytime —
            backed by our 30-day money-back guarantee.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Button
              size="lg"
              className="glow-neon w-full bg-primary font-semibold text-primary-foreground hover:bg-primary/90 sm:w-auto"
            >
              Unlock Signals Now
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="w-full border-border bg-transparent text-foreground hover:bg-secondary sm:w-auto"
            >
              View Pricing Plans
            </Button>
          </div>
        </div>
      </section>

      <footer className="border-t border-border bg-background">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-4 py-8 sm:flex-row sm:px-6">
          <div className="flex items-center gap-2">
            <span className="flex h-7 w-7 items-center justify-center rounded-md bg-primary/15 ring-1 ring-primary/40">
              <Activity className="h-3.5 w-3.5 text-primary" aria-hidden="true" />
            </span>
            <span className="font-mono text-xs font-bold tracking-widest">
              NEON<span className="text-primary">FORECAST</span>
            </span>
          </div>
          <p className="text-center text-xs text-muted-foreground">
            Forecasts are informational only and not financial advice. Trade responsibly.
          </p>
          <p className="font-mono text-xs text-muted-foreground">© 2026 Neon Forecast</p>
        </div>
      </footer>
    </main>
  )
}
